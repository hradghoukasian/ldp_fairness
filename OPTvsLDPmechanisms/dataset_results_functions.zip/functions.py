from sklearn.metrics import accuracy_score, recall_score
import numpy as np
from sys import maxsize
import xxhash
import copy
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from numba import jit

# multi-freq-ldpy import
from multi_freq_ldpy.pure_frequency_oracles.GRR import GRR_Client
from multi_freq_ldpy.pure_frequency_oracles.UE import UE_Client
from multi_freq_ldpy.pure_frequency_oracles.HE import HE_Client
from multi_freq_ldpy.pure_frequency_oracles.LH import LH_Client
from multi_freq_ldpy.pure_frequency_oracles.SS import SS_Client

from scipy import optimize

def find_tresh(tresh, epsilon):    
    
    return (2 * (np.exp(epsilon*tresh/2)) - 1) / (1 + (np.exp(epsilon*(tresh-1/2))) - 2*(np.exp(epsilon*tresh/2)))**2

def LH_Client_Fast(input_data, k, epsilon, optimal=True):
    
    # Binary LH (BLH) parameter
    g = 2
    
    # Optimal LH (OLH) parameter
    if optimal:
        g = int(round(np.exp(epsilon))) + 1
    
    # GRR parameters with reduced domain size g
    p = np.exp(epsilon) / (np.exp(epsilon) + g - 1)
    q = 1 / (np.exp(epsilon) + g - 1)
    
    # Generate random seed and hash the user's value
    rnd_seed = np.random.randint(0, maxsize, dtype=np.int64)
    hashed_input_data = (xxhash.xxh32(str(input_data), seed=rnd_seed).intdigest() % g)
    
    # LH perturbation function (i.e., GRR-based)
    sanitized_value = hashed_input_data
    rnd = np.random.random()
    if rnd > p - q:
        
        sanitized_value = np.random.randint(0, g)
        
    return (sanitized_value, rnd_seed)


def get_preprocessed_encoded_sets_with_ldp(df, target, test_size, seed, lst_sensitive_att, epsilon, split_strategy, lst_k, mechanism='GRR'):
    def LH_Client_high_eps(input_data, k, epsilon, optimal=True):
        """Backup function for OLH mechanism.
        Due to high epsilon values, the new
        domain size g is excessively high.
        Multi-freq-ldpy fails with np.random.randint.
        This new function uses np.random.uniform."""

        # Binary LH (BLH) parameter
        g = 2

        # Optimal LH (OLH) parameter
        if optimal:
            g = int(round(np.exp(epsilon))) + 1

        # Generate random seed and hash the user's value
        rnd_seed = np.random.randint(0, maxsize, dtype=np.int64)
        hashed_input_data = (xxhash.xxh32(str(input_data), seed=rnd_seed).intdigest() % g)

        # LH perturbation function (i.e., GRR-based)
        p = np.exp(epsilon) / (np.exp(epsilon) + g - 1)
        if np.random.random() <= p:
            sanitized_value = int(np.random.uniform() * g)
            while sanitized_value == hashed_input_data:
                sanitized_value = int(np.random.uniform() * g)        
            return (sanitized_value, rnd_seed)

        return (hashed_input_data, rnd_seed)
    
    # Use original dataset
    X = copy.deepcopy(df.drop(target, axis=1))
    y = copy.deepcopy(df[target])

    # Train test splitting
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, shuffle=True, stratify=y, random_state=seed)
    y_train.reset_index(inplace=True, drop=True)
    y_test.reset_index(inplace=True, drop=True)

    # One-Hot-Encoding + LDP randomization
    lst_df_train = []
    lst_df_test = []
    for col in list(set(df.columns) - set([target])):

        lst_col_name = [col+"_{}".format(val) for val in range(len(set(df[col])))]
        k = len(set(df[col]))
        OHE = np.eye(k)

        if col in lst_sensitive_att: # LDP randomization
            eps_att = epsilon / len(lst_sensitive_att) if split_strategy=='uniform' else epsilon * k / sum(lst_k.values())
            
            if mechanism == 'GRR':
                df_ohe = pd.DataFrame([OHE[GRR_Client(val, k, eps_att)] for val in X_train[col]], columns=lst_col_name)
                
            elif mechanism == 'BLH':
                df_ohe = pd.DataFrame([IVE_LH(LH_Client(val, k, eps_att, optimal=False), k, eps_att, optimal=False) for val in X_train[col]], columns=lst_col_name)
            
            elif mechanism == 'OLH':
                if eps_att <= 21:
                    df_ohe = pd.DataFrame([IVE_LH(LH_Client_Fast(val, k, eps_att, optimal=True), k, eps_att, optimal=True) for val in X_train[col]], columns=lst_col_name)
                else:
                    df_ohe = pd.DataFrame([IVE_LH(LH_Client_high_eps(val, k, eps_att, optimal=True), k, eps_att, optimal=True) for val in X_train[col]], columns=lst_col_name)
            
            elif mechanism == 'SUE':
                df_ohe = pd.DataFrame(np.stack(X_train[col].apply(lambda x: UE_Client(x, k, eps_att, optimal=False))), columns=lst_col_name) 
                
            elif mechanism == 'OUE':
                df_ohe = pd.DataFrame(np.stack(X_train[col].apply(lambda x: UE_Client(x, k, eps_att, optimal=True))), columns=lst_col_name)
                
            elif mechanism == 'SS':
                df_ohe = pd.DataFrame([IVE_SS(SS_Client(val, k, eps_att), k) for val in X_train[col]], columns=lst_col_name)
                
            elif mechanism == 'THE':
                res_tresh = optimize.minimize_scalar(find_tresh, bounds=[0,1], method='bounded', args=(eps_att))
                tresh_att = res_tresh.x

                df_ohe = pd.DataFrame([IVE_THE(HE_Client(val, k, eps_att), k, tresh_att) for val in X_train[col]], columns=lst_col_name)
            
            else:
                raise ValueError("Mechanism unknown!")
        else: # just one-hot-encoding
            df_ohe = pd.DataFrame([OHE[val] for val in X_train[col]], columns=lst_col_name)

        lst_df_train.append(df_ohe)

        # test set is original, i.e., just one-hot-encoding
        df_ohe_test = pd.DataFrame([OHE[val] for val in X_test[col]], columns=lst_col_name)
        lst_df_test.append(df_ohe_test)

    # concat one-hot-encoded train/test sets
    X_train = pd.concat(lst_df_train, axis=1)
    X_test = pd.concat(lst_df_test, axis=1)
    
    return X_train, X_test, y_train, y_test

   
def fairness_metrics(df_fm, protected_attribute, target):
    # Find all columns corresponding to the protected attribute
    protected_cols = [col for col in df_fm.columns if col.startswith(protected_attribute + "_")]
    
    # Initialize metrics
    SPD = -np.inf  # Maximum SPD value
    EOD = -np.inf  # Maximum EOD value
    OAD = -np.inf  # Maximum OAD value

    # Iterate over all pairs of protected groups (i.e., one-hot encoded columns)
    for i in range(len(protected_cols)):
        for j in range(i + 1, len(protected_cols)):
            group_i_col = protected_cols[i]
            group_j_col = protected_cols[j]

            # Filter datasets by groups
            df_group_i = df_fm[df_fm[group_i_col] == 1]
            df_group_j = df_fm[df_fm[group_j_col] == 1]

            # Calculate Statistical Parity (SP) for both groups
            SP_group_i = df_group_i[df_group_i["y_pred"] == 1].shape[0] / df_group_i.shape[0]
            SP_group_j = df_group_j[df_group_j["y_pred"] == 1].shape[0] / df_group_j.shape[0]
                
            # Update SPD as the maximum difference
            SPD = max(SPD, abs(SP_group_i - SP_group_j))

            # Calculate Equal Opportunity (EO) for both groups
            EO_group_i = recall_score(df_group_i[target], df_group_i['y_pred'])
            EO_group_j = recall_score(df_group_j[target], df_group_j['y_pred'])
                
            # Update EOD as the maximum difference
            EOD = max(EOD, abs(EO_group_i - EO_group_j))

            # Calculate Overall Accuracy (OA) for both groups
            OA_group_i = accuracy_score(df_group_i[target], df_group_i['y_pred'])
            OA_group_j = accuracy_score(df_group_j[target], df_group_j['y_pred'])
                
            # Update OAD as the maximum difference
            OAD = max(OAD, abs(OA_group_i - OA_group_j))

    # Return only the three relevant metrics
    return {
        "SPD": SPD,
        "EOD": EOD,
        "OAD": OAD
    }



def IVE_LH(val_seed, k, epsilon, optimal=True):
    """
    Indicator-Vector-Encoding (IVE) for Local Hashing (LH) Mechanisms.
    """
    
    g=2 # BLH parameter
    if optimal:
        g = int(np.round(np.exp(epsilon))) + 1 # OLH parameter
    
    ive_lh = np.zeros(k)

    for v in range(k):
        if val_seed[0] == (xxhash.xxh32(str(v), seed=val_seed[1]).intdigest() % g):
            ive_lh[v] = 1
    
    return ive_lh    
    
def IVE_SS(ss, k):
    """
    Indicator-Vector-Encoding (IVE) for Subset Selection (SS) Mechanism.
    """
    
    ive_ss = np.zeros(k)
    ive_ss[ss] = 1
    
    return ive_ss    
    
def IVE_THE(hist, k, thresh):
    """
    Indicator-Vector-Encoding (IVE) for Thresholding with Histogram Encoding (THE) Mechanism.
    """
    
    ss_the = np.where(hist > thresh)[0]
    
    ive_the = np.zeros(k)
    
    if len(ss_the) > 0:
        ive_the[ss_the] = 1
    
    return ive_the    
    
